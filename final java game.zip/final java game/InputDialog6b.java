import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.*;
import java.util.*;
import javax.swing.UIManager;
import java.applet.*;
import  sun.audio.*; 


public class InputDialog6b {

    public static void main(String[] args) {
		AudioClip ac = getAudioClip(getCodeBase(), soundFile);
ac.play();   //play once
ac.stop();   //stop playing
ac.loop();   //play continuously

    try {
        AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File("D:/MusicPlayer/fml.mp3").getAbsoluteFile());
        Clip clip = AudioSystem.getClip();
        clip.open(audioInputStream);
        clip.start();
    } catch(Exception ex) {
        System.out.println("Error with playing sound.");
        ex.printStackTrace();
    }
}

    }


